import numpy as np

# 허수 표현할때 i가 아닌 j를 쓰며 j앞에 반드시 숫자가 있어야함을 주의
A = np.array( [ [1-2j, 3+1j, 1], [1+2j, 2-1j, 7] ] )

b = np.array( [1+8j, -2j] )

print(A)
print(b)

# shape도 문제없이 사용가능
print(A.shape)
print(b.shape)