import numpy as np

# real 행렬 생성
A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ], dtype=np.float64 )

# A entry의 타입 출력
print(type(A[0,0]))

# complex128로 변환
A = A.astype(dtype=np.complex128)

# 변환된 타입 출력 A entry의 타입 출력
print(type(A[0,0]))