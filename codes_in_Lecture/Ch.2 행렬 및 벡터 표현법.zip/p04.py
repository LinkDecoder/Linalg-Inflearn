import numpy as np

# 2D array로 행렬 생성
A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ] )

# 1D array로 벡터 생성
b = np.array( [7.0,5.0,3.0] )

# 기본 print 기능을 변수 A출력
print(A)

# 보기 편하게 한줄 공백 출력
print()

# b 변수 출력
print(b)

# A의 shape출력
print(A.shape)

# shape[0] 출력: 행렬로 생각했을때 행의 개수
print(A.shape[0])

# shape[1] 출력: 행렬로 생각했을때 열의 개수
print(A.shape[1])

# b shape출력, 결과로 (3,)가 나옴, (n,) 이 형태가 나오면 1D array라는걸 알 수 있음
print(b.shape)

# b shape[0] 출력
print(b.shape[0])

# b shape[1] 시도하면 오류
#print(b.shape[1])