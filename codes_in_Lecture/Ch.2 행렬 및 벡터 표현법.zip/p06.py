import numpy as np

# 2D array로 행렬 생성
A = np.array( [ [1,2.5,3], [-1,-2,-1.5], [4,5.5,6] ] )

# 1D array로 벡터 생성
b = np.array( [7.0,5.0,3.0] )

# A 출력
print(A)

# b 출력
print(b)

# A의 entry에 접근하여 출력해보기
print(A[1,1])
print(A[2,2])

# A의 entry에 접근하여 값 바꾸기
A[1,1] = 0.0
A[2,2] = 0.0

# 다시 A출력 해보기 
print(A)

# b도 마찬가지 형태로 접근해서 바꿔볼수있음
b[0] = 0.0
print(b)