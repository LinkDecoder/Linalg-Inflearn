import numpy as np

# 2D array로 행렬 생성 이는 사실 dtype=np.float64 (double precision)이 생략된 형태
A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ] )

# 위와 동일한 표현법
#A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ] , dtype=np.float64 )

# 아래는 entry 타입을 complex128로 한 경우 (real과 imaginary 부분이 각각 double precision의 정확도를 지님)
#A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ] , dtype=np.complex128 )

# real 행렬인데 허수를 넣으려 한다면? 오류, dtype=np.complex128이었다면 오류가 없음
A[1,1] = 0+0j
