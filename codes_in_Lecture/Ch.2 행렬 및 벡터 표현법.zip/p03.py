import numpy as np

# 2D array로 행렬 생성
A = np.array( [ [1,2.5,3], [-1,-2,-1.5] ] )

# 1D array로 벡터 생성
b = np.array( [7.0,5.0,3.0] )

# 기본 print 기능을 변수 A출력
print(A)

# 보기 편하게 한줄 공백 출력
print()

# b 변수 출력
print(b)