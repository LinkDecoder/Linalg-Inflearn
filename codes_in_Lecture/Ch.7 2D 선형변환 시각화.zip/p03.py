import numpy as np
from custom_ani import lin_tran_ani

A = np.array([[1,1],[0,1]])

lin_tran_ani(A,(-3,3),(-3,3))