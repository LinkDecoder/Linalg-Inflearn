from custom_ani import tsvd_img_ani

tsvd_img_ani("flower.jpg", reverse=False)