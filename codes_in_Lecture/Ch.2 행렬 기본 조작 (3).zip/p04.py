import numpy as np

A = np.array([[1,2],[3,4]],dtype=np.float64)

r = 5

# A + r도 동일
result = r + A
print(result)